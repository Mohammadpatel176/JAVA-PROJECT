import javax.swing.*;
import javax.swing.JTable.PrintMode;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
//import javax.swing.text.Document;
import javax.swing.border.Border;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.print.PrinterException;
//import java.io.*;
import java.util.*;
//import java.sql.*;

class AttendancePanel implements ActionListener{
    JButton ClassnameButton;
    JButton newstudent = new JButton("+ Add Student");
    JButton newdate = new JButton("+ New day");
    JButton refresh = new JButton("Refresh");
    JLabel classNameLabel;
    Table newTable;
    JPanel newPanel;
    JButton printTable = new JButton("Print");
    Border border = new LineBorder(new Color(200,200,200), 1, true);

    AttendancePanel(AttendanceFrame obj, String classname){       
        newPanel = new JPanel();
        ClassnameButton = new JButton(classname);
        classNameLabel = new JLabel(classname);

        newPanel.setBounds(180, 50, obj.w-180, obj.h-50);
        newPanel.setBackground(Color.white);
        newPanel.setVisible(true);
        newPanel.setLayout(null);
        obj.attendanceregister.add(newPanel);

        newstudent.setBounds(40, 80, 140, 30);
        newstudent.setBackground(Color.white);
        newstudent.setForeground(Color.black);
        newstudent.setFont(new Font("Candara",Font.PLAIN,18));
        newstudent.setBorder(null);
        newstudent.setFocusPainted(false);
        newstudent.addActionListener(this);
        newstudent.setVerticalAlignment(JButton.CENTER);
        newPanel.add(newstudent);

        refresh.setBounds(600, 80, 140, 30);
        refresh.setBackground(Color.white);
        refresh.setForeground(Color.black);
        refresh.setFont(new Font("Candara",Font.PLAIN,18));
        refresh.setBorder(border);
        refresh.setFocusPainted(false);
        refresh.addActionListener(this);
        refresh.setVerticalAlignment(JButton.CENTER);
        newPanel.add(refresh);

        newdate.setBounds(240, 80, 140, 30);
        newdate.setBackground(Color.white);
        newdate.setForeground(Color.black);
        newdate.setFont(new Font("Candara",Font.PLAIN,18));
        newdate.setBorder(null);
        newdate.setFocusPainted(false);
        newdate.addActionListener(this);
        //newdate.setVerticalAlignment(JButton.CENTER);
        newPanel.add(newdate);

        printTable.setBounds(400, 80, 140, 30);
        printTable.setBackground(Color.white);
        printTable.setForeground(Color.black);
        printTable.setFont(new Font("Candara",Font.PLAIN,18));
        printTable.setBorder(border);
        printTable.setFocusPainted(false);
        printTable.addActionListener(this);
        printTable.setVerticalAlignment(JButton.CENTER);
        printTable.setLayout(null);
        printTable.addActionListener(this);
        newPanel.add(printTable);

        classNameLabel.setBounds(40,20,200,40);
        classNameLabel.setBackground(Color.white);
        classNameLabel.setForeground(Color.black);
        classNameLabel.setFont(new Font("verdana",Font.PLAIN,30));
        newPanel.add(classNameLabel);

        newTable = new Table(newPanel, obj);

        int cal = 120 + obj.downClass*30;
        ClassnameButton.setBounds(0, cal, 180, 30);
        obj.downClass++;
        cal = 120 + obj.downClass*30;
        obj.addclass.setBounds(0,cal,180,30);
        ClassnameButton.setBackground(new Color(30,144,255));
        ClassnameButton.setFont(new Font("verdana",Font.PLAIN,18));
        ClassnameButton.setBorder(null);
        ClassnameButton.setForeground(Color.white);
        ClassnameButton.setFocusPainted(false);
        ClassnameButton.addActionListener(this);
        obj.attendanceregister.add(ClassnameButton);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton a = (JButton) e.getSource();
        if(a.equals(ClassnameButton)){
            AttendancePanel at = null;
            Iterator<AttendancePanel> itr = List.listPanel.iterator();
            while(itr.hasNext()){
                at = itr.next();
            at.newPanel.setVisible(false);
            at.ClassnameButton.setBackground(new Color(30,144,255));
            at.ClassnameButton.setForeground(Color.white);
            }
            this.newPanel.setVisible(true);
            this.ClassnameButton.setBackground(Color.white);
            this.ClassnameButton.setForeground(new Color(30,144,255));
            at=null;
        }
        else if(a.equals(newstudent)){
            String enno = JOptionPane.showInputDialog( null,"Enter Enrollement no.");
            String name = JOptionPane.showInputDialog( null,"Enter name");
            try{
                if( (enno.equals("")) || (name.equals(""))){
                    return;
                }
            }catch(NullPointerException k){
                return;
            }
            newTable.addRows(name, enno);
        }
        else if(a.equals(newdate)){
            String date = JOptionPane.showInputDialog( null,"Enter Date (dd/mm/yy)");
            try{
                if(date.equals(""))
                    return;
            }catch(NullPointerException k){
                return;
            }
            newTable.addColumns(date);
        }
        else if(a.equals(refresh)){
            newTable.rowCount();
            newTable.colCount();
            newTable.Refresh();
        }
        else if(a.equals(printTable)){
            newTable.Print();
        }
    }
}

class Table{
    JTable attendanceTable;
    int rowheight = 30;
    int rowCount = 1;
    int tableheight = 30 + rowheight*rowCount;
    String [][]rows = {};
    String[] cols = {"Enrolllment no.", "Name"};
    JScrollPane sp;
    DefaultTableModel model = new DefaultTableModel(); 
    int rowStudentPresent=0;
    int colStudentPresent=0;
    TableColumnModel ColumnModel;
    Table(JPanel thisPanel, AttendanceFrame obj){
        attendanceTable = new JTable(model);
        model.addColumn("Enrollment no."); 
        model.addColumn("Name");
        model.addColumn("Total");
        model.addRow(new Object[]{"","Total",""});
        attendanceTable.setFont(new Font("Cambria",Font.PLAIN,18));
        attendanceTable.setBackground(Color.white);
        attendanceTable.setRowHeight(30);
        attendanceTable.getTableHeader().setFont(new Font("Cambria",Font.BOLD,20));
        attendanceTable.setAutoscrolls(true);
        ColumnModel = attendanceTable.getColumnModel();
        ColumnModel.getColumn(0).setPreferredWidth(150);
        ColumnModel.getColumn(1).setPreferredWidth(100);

        sp = new JScrollPane(attendanceTable);
        sp.setBounds(40,150,obj.w - 240, obj.h - 120);
        sp.setBackground(Color.white);
        sp.setEnabled(true);
        sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);  
        thisPanel.add(sp);
    }

    void rowCount(){
        for(int i=1;i<attendanceTable.getRowCount();i++){
            rowStudentPresent = 0;
            for(int j=3;j<attendanceTable.getColumnCount();j++){
                String validate = (String) attendanceTable.getValueAt(i, j);
                try{
                    if(validate.equals("Y") || validate.equals("y")){
                        rowStudentPresent++;
                    }
                }catch(NullPointerException k){
                    //Do nothing
                }
            }
            attendanceTable.setValueAt(rowStudentPresent, i, 2);
        }
        rowStudentPresent=0;
    }

    void colCount(){
        for(int i=3;i<attendanceTable.getColumnCount();i++){
            colStudentPresent = 0;
            for(int j=1;j<attendanceTable.getRowCount();j++){
                String validate = (String) attendanceTable.getValueAt(j, i);
                try{
                    if(validate.equals("Y") || validate.equals("y")){
                        colStudentPresent++;
                    }
                }catch(NullPointerException k){
                    // Do nothing
                }
            }
            attendanceTable.setValueAt(colStudentPresent, 0, i);
        }
        colStudentPresent=0;
    }

    void Refresh(){
        ColumnModel.getColumn(0).setPreferredWidth(150);
        ColumnModel.getColumn(1).setPreferredWidth(100);
        for(int i=2;i<attendanceTable.getColumnCount();i++){
            ColumnModel.getColumn(i).setPreferredWidth(80);
        }
    }

    void Print(){
        try{
            attendanceTable.print(PrintMode.FIT_WIDTH);
        }catch (PrinterException e){
            // Do nothing
        }    
    }

    void addRows(String name, String enno){
        model.addRow(new Object[]{enno, name});
    }

    void addColumns(String date){
        model.addColumn(date);
        attendanceTable.getColumnModel().getColumn(0).setPreferredWidth(150);
        attendanceTable.getColumnModel().getColumn(0).setPreferredWidth(100);
    }
}

class List{
    static ArrayList<AttendancePanel> listPanel = new ArrayList<AttendancePanel>();
    
    Iterator<AttendancePanel> addPanel(AttendancePanel obj){
        listPanel.add(obj);
        Iterator<AttendancePanel> itr=listPanel.iterator(); 
        return itr; 
    }

}

class AttendanceFrame implements ActionListener{
    JFrame attendanceregister;
    JButton logout;
    JButton addclass;
    Dimension screen;
    List classChain;
    int downClass;
    int h;
    int w;
    Border border = new LineBorder(new Color(255,255,255), 2, true);

    void openRegister(){
        attendanceregister = new JFrame("Attendance");
        addclass = new JButton("+ New Class");
        logout = new JButton("Logout");
        screen = Toolkit.getDefaultToolkit().getScreenSize();
        classChain = new List();
        downClass = 0;
        h = screen.height - 50;
        w = screen.width;

        attendanceregister.setSize(w,h);
        attendanceregister.getContentPane().setBackground(new Color(30,144,255));
        attendanceregister.setLocationRelativeTo(null);
        attendanceregister.setLayout(null);
        attendanceregister.setVisible(true);

        logout.setBounds(w-120, 10,100,30);
        logout.setBackground(new Color(30,144,255));
        logout.setForeground(Color.white);
        logout.setBorder(border);
        logout.setFont(new Font("verdana",Font.PLAIN,18));
        logout.setFocusPainted(false);
        logout.addActionListener(this);
        attendanceregister.add(logout);

        addclass.setBounds(0, 120, 180, 30);
        addclass.setBackground(new Color(30,144,255));
        addclass.setFont(new Font("verdana",Font.PLAIN,18));
        addclass.setBorder(null);
        addclass.setForeground(Color.white);
        addclass.setFocusPainted(false);
        addclass.addActionListener(this);
        attendanceregister.add(addclass);
    }

    public void actionPerformed(ActionEvent e) {
        JButton a = (JButton) e.getSource();
        if(a.equals(addclass)){
            String classname = JOptionPane.showInputDialog( null,"Enter class name:");
            try{
                if(classname.equals("")){
                    return;
                }
            }catch(NullPointerException n){
                return;
            }
            AttendancePanel newClass = new AttendancePanel(this, classname);
            Iterator<AttendancePanel> itr = classChain.addPanel(newClass);
            AttendancePanel at = null;

            while(itr.hasNext()){ 
                at = itr.next();
                at.newPanel.setVisible(false);  
            }
            newClass.newPanel.setVisible(true);
        }
        else if(a.equals(logout)){
            new Login();
            attendanceregister.dispose();
        }
    }
}

public class AttendanceSheet{
    AttendanceSheet(){
        AttendanceFrame af = new AttendanceFrame();
        af.openRegister();
    }
}