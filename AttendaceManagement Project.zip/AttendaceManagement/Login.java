import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

class LoginForm implements ActionListener{
    JFrame loginFrame = new JFrame(""); //Creating Login frame
    JLabel loginLabel = new JLabel("LOGIN"); //Creating LOGIN title
    JLabel username = new JLabel("Username:"); //Creating label username
    JLabel password = new JLabel("Password:"); //Creating label password
    JTextField tusername = new JTextField(); //Creating textbox of username
    JPasswordField tpassword = new JPasswordField(); //Creating password field
    JButton runlogin = new JButton("Login"); //Creating login button
    JButton clear = new JButton("Clear"); //Creating clear button
    JButton closeframe = new JButton("x");//Creating close button
    Border border = new LineBorder(Color.white, 2, true); //Creating border object with style

    /* login Function for calling Login form */
    public boolean login(){
        /* Login Button Style and Event */
        runlogin.setBounds(120, 210, 100,40);
        runlogin.setBackground(new Color(30,144,255));
        runlogin.setFont(new Font("verdana",Font.PLAIN,18));
        runlogin.setBorder(null);
        runlogin.setForeground(Color.white);
        runlogin.setBorder(border);
        runlogin.setFocusPainted(false);
        runlogin.addActionListener(this); // Calling for the action on click
        loginFrame.add(runlogin);

        closeframe.setBounds(470, 8, 18,18);
        closeframe.setBackground(new Color(30,144,255));
        closeframe.setFont(new Font("verdana",Font.PLAIN,18));
        closeframe.setBorder(null);
        closeframe.setForeground(Color.white);
        closeframe.setBorder(null);
        closeframe.setFocusPainted(false);
        closeframe.addActionListener(this); // Calling for the action on click
        loginFrame.add(closeframe);

        /* Clear Button Style and Event */
        clear.setBounds(280, 210, 100,40);
        clear.setBackground(new Color(30,144,255));
        clear.setFont(new Font("verdana",Font.PLAIN,18));
        clear.setBorder(null);
        clear.setForeground(Color.white);
        clear.setBorder(border);
        clear.setFocusPainted(false);
        clear.addActionListener(this); // Calling for the action on click
        loginFrame.add(clear);

        // Defining username textbox style
        tusername.setBounds(220,110,180,30);
        tusername.setBackground(Color.white);
        tusername.setFont(new Font("verdana",Font.PLAIN,18));
        tusername.setBorder(null);
        loginFrame.add(tusername);

        // Defining password field with style
        tpassword.setBounds(220,150,180,30);
        tpassword.setBackground(Color.white);
        tpassword.setFont(new Font("verdana",Font.PLAIN,18));
        tpassword.setBorder(null);
        loginFrame.add(tpassword);

        // Defining label Username:
        username.setBounds(120, 110, 100, 30);
        username.setFont(new Font("candara",Font.PLAIN,20));
        username.setForeground(Color.white);
        loginFrame.add(username);

        // Defining label Password:
        password.setBounds(120, 150, 100, 30);
        password.setFont(new Font("candara",Font.PLAIN,20));
        password.setForeground(Color.white);
        loginFrame.add(password);

        // Defining Login label
        loginLabel.setBounds(175, 30, 150, 50);
        loginLabel.setFont(new Font("candara",Font.BOLD,50));
        loginLabel.setForeground(Color.white);
        loginFrame.add(loginLabel);

        // Defining login form frame
        loginFrame.setSize(500,300);
        loginFrame.getContentPane().setBackground(new Color(30,144,255));
        loginFrame.setLocationRelativeTo(null);
        loginFrame.setLayout(null);
        loginFrame.setUndecorated(true);
        loginFrame.setVisible(true);

        return false;
    }

    public void actionPerformed(ActionEvent e){  
        JButton a = (JButton) e.getSource();

        if(a.equals(clear)){
            tusername.setText("");
            tpassword.setText("");
        }
        else if(a.equals(runlogin)){
            if(tusername.getText().toLowerCase().equals("naitik_soni") && tpassword.getText().equals("Abcd@1234")){
                loginSuccessfull();
            }
            else{
                JOptionPane.showMessageDialog(null, "Invalid Login credentials");
            }
        }
        else if(a.equals(closeframe)){
            loginFrame.dispose();
        }
    }
    void loginSuccessfull(){
        new AttendanceSheet();
        loginFrame.dispose();
    }
}

public class Login{
    Login(){
        LoginForm create = new LoginForm();
        create.login();
    }
}